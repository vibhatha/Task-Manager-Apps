/**
* Later.js
* (c) 2015 Bill, Levelstory, Inc.
* Later is freely distributable under the MIT license.
* For all details and documentation:
*     http://bunkat.github.com/later
*/
later = (function() {
  'use strict';

  var later = {version: "1.1.10"}; // semver